
/************************************************
*      Filename: main.c
*        Author: litao.wang
*   Description: 
*        Create: 2018-10-11 03:38:22
* Last Modified: 2018-10-11 03:52:56
*************************************************/
#include <stdio.h>

int 


main
(void)
{
	printf
		("hello world!\n")
		
		;
	return 
		
		
		0
		
		
		
		;
}
